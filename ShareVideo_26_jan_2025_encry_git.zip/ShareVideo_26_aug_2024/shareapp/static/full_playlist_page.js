document.addEventListener('DOMContentLoaded', function () {
    const searchInput = document.getElementById('searchInput');
    const videoItems = document.querySelectorAll('.video-item');

    var entryContent = document.querySelector('.playlist_content');
    const all_decs = entryContent.querySelectorAll("p");
    const all_title = entryContent.querySelectorAll("h3");
    searchInput.addEventListener('keyup', function () {
        const filter = searchInput.value.toLowerCase();
            var i =0;
        all_decs.forEach(item => {
            // Clear previous highlights
            all_title[i].innerHTML = all_title[i].textContent;
            item.innerHTML = item.textContent;

            const title = all_title[i].textContent.toLowerCase();
            const description = item.textContent.toLowerCase();
            
            if (title.includes(filter) || description.includes(filter)) {
                item.parentElement.parentElement.style.display = ''; // Show item
                highlightText(all_title[i], filter);
                highlightText(item, filter);
            } else {
                item.parentElement.parentElement.style.display = 'none'; // Hide item
            }
       i=i+1; });
    });

    function highlightText(element, searchTerm) {
        if (!searchTerm) return;

        const regex = new RegExp(`(${searchTerm})`, 'gi');
        element.innerHTML = element.textContent.replace(regex, '<span class="highlight">$1</span>');
    }
});
// Optional: Close dropdown when clicking outside of it
window.onclick = function(event) {
    if (!event.target.matches('.settings-button')) {
        const dropdown = document.getElementById("settingsDropdown");
        if (dropdown.style.display === "block") {
            dropdown.style.display = "none";
        }
    }
}


// playlist settings dropdown
function toggleDropdown() {
    const dropdown = document.getElementById("settingsDropdown");
    dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
}

// Playlist order change
const list = document.getElementById('upper_lvl_playlist');
console.log("all list elements " + list);
const editButton = document.getElementById('editButton');

let draggingItem = null;
let editMode = false;

editButton.addEventListener('click', () => {
   
    editMode = !editMode;
    editButton.textContent = editMode ? 'You are in editing mode' : 'Change the Playlist Order';
    if(editMode){
        const additionalButtons = document.getElementById('additionalButtons');
        additionalButtons.style.display = 'block';
    }
    if (!editMode) {

        // Remove dragging class from all items when done editing
        [...list.children].forEach(item => item.classList.remove('dragging'));
    }
});

list.addEventListener('dragstart', (e) => {
    if (!editMode) return; // Only allow dragging in edit mode
    draggingItem = e.target;
    console.log("dragstart dragging item" + draggingItem);
    e.target.classList.add('dragging');
});

list.addEventListener('dragend', (e) => {
    e.target.classList.remove('dragging');
    draggingItem = null;
});

list.addEventListener('dragover', (e) => {
    if (!editMode) return; // Only allow dragging in edit mode
    e.preventDefault();
    const afterElement = getDragAfterElement(list, e.clientY);
    console.log(afterElement);
    console.log("dragging item " + draggingItem);
    console.log("After element" +afterElement.parentElement);
    if (afterElement == null) {
        list.appendChild(draggingItem);
    } else {
        list.insertBefore(draggingItem, afterElement.parentElement);
    }
});

function getDragAfterElement(container, y) {
    const draggableElements = [...container.querySelectorAll('div:not(.dragging)')];

    return draggableElements.reduce((closest, child) => {
        const box = child.getBoundingClientRect();
        const offset = y - box.top - box.height / 2;

        if (offset < 0 && offset > closest.offset) {
            return { offset: offset, element: child };
        } else {
            return closest;
        }
    }, { offset: Number.NEGATIVE_INFINITY }).element;
}

function handleCancel() {
    // Hide the OK and Cancel buttons
    const additionalButtons = document.getElementById('additionalButtons');
    additionalButtons.style.display = 'none';
    editMode = !editMode;
    editButton.textContent = editMode ? 'You are in editing mode' : 'Change the Playlist Order';


}


function handleOk() {
    const additionalButtons = document.getElementById('additionalButtons');
    additionalButtons.style.display = 'none';
    editMode = !editMode;
    editButton.textContent = editMode ? 'You are in editing mode' : 'Change the Playlist Order';
    alert("changes saved")
}