// let's select all required tags or elements

const video_palyer = document.querySelector("#video_player"),
mainVideo = video_palyer.querySelector('#main_video'),
progressAreaTime = video_palyer.querySelector('.progressAreaTime'),
controls = video_palyer.querySelector('.controls'),
progressArea = video_palyer.querySelector('.progress_area'),
progress_Bar = video_palyer.querySelector('.progress_bar'),
fast_rewind = video_palyer.querySelector('.fast-rewind'),
play_pause = video_palyer.querySelector('.play_arrow'),
fast_forward = video_palyer.querySelector('.fast-forward'),
volume = video_palyer.querySelector('.volume'),
volume_range = video_palyer.querySelector('.volume_range'),
current = video_palyer.querySelector('.current'),
duration = video_palyer.querySelector('.duration'),
auto_play = video_palyer.querySelector('.auto.play'),
settingsBtn = video_palyer.querySelector('.settingsBtn'),
picture_in_picture = video_palyer.querySelector('.picture_in_picture'),
fullscreen = video_palyer.querySelector('.fullscreen'),
settings = video_palyer.querySelector('#settings'),
settingshome = video_palyer.querySelectorAll('#settings [data-label="settingsHome"] > ul > li'),
playback = video_player.querySelectorAll(".playback li"),
real_volume = video_palyer.querySelector('#volume');

const like_count = document.getElementById("like_count");

const dislk_count = document.getElementById("dislike_count");
// play video function
function playVideo(){
play_pause.innerHTML ="pause";
play_pause.title ="pause";
video_palyer.classList.add("paused")
mainVideo.play();

}

// pause video function
function pauseVideo(){
play_pause.innerHTML ="play_arrow";
play_pause.title ="play";
video_palyer.classList.remove("paused")
mainVideo.pause();
}

play_pause.addEventListener('click',()=>{
const isVideopaused = video_palyer.classList.contains('paused');
isVideopaused ? pauseVideo(): playVideo();
}
)

mainVideo.addEventListener('pause',()=>{
    pauseVideo();
}
)

mainVideo.addEventListener('play',()=>{
    playVideo();
}
)

  // fast_rewind video function

 fast_rewind.addEventListener('click',()=>{
     console.log("i am rewind")
    mainVideo.currentTime -=10;
 })
 
  // fast_forward video function

  fast_forward.addEventListener('click',()=>{
    mainVideo.currentTime +=10;
 })
 

// Load video duration

mainVideo.addEventListener('loadeddata',(e)=>{
    let videoDuration = e.target.duration;
    let totalMin = Math.floor(videoDuration/60);
    let totalSec  = Math.floor(videoDuration%60);

    // if seconds are less then 10 add 0 ai the begining
    totalSec < 10 ? totalSec ="0"+totalSec : totalSec;
    duration.innerHTML =  totalMin +":"+ totalSec;
})

// Current video duration

mainVideo.addEventListener('timeupdate',(e)=>{
    let currentVideoTime = e.target.currentTime;
    let currentMin = Math.floor(currentVideoTime/60);
    let currentSec = Math.floor(currentVideoTime % 60);

    currentSec < 10 ? currentSec ="0"+currentSec : currentSec;
    current.innerHTML = currentMin +":"+ currentSec;

// progressbar width change
let videoDuration = e.target.duration

let progressWidth = (currentVideoTime/videoDuration)*100;
progress_Bar.style.width = progressWidth +"%";
}
)

// update the playing video current time on according to click 

progressArea.addEventListener('click',(e)=>{
let videoDuration = mainVideo.duration;
let progressWidthval = progressArea.clientWidth;
let clickoffsetx = e.offsetX;

mainVideo.currentTime =(clickoffsetx / progressWidthval)*videoDuration;

})

function changeVolume(){
mainVideo.volume =  volume_range.value/100;

if(volume_range.value==0){
    real_volume.innerHTML = "volume_off";
   
}

else if(volume_range.value<20){
    // volume_range.value = 15;
    real_volume.innerHTML = "volume_down";
}

else {
    // volume_range.value = 70;
    real_volume.innerHTML = "volume_up";
}

}

function muteVolume(){
    if(volume_range.value ===0){   
      volume_range.value = 75;
        real_volume.innerHTML = "volume_up";
    }
    else{
        volume_range.value = 0;
       
        real_volume.innerHTML = "volume_off";
       
    }

}


volume_range.addEventListener('change',()=>{
    changeVolume();
})

volume_range.addEventListener('input',changeVolume);

// volume.addEventListener('click',()=>{
//     muteVolume();
// })


// Update progress area time and display block on mouse move

progressArea.addEventListener('mousemove',(e)=>{
    let progressWidthval=progressArea.clientWidth;
    let x = e.offsetX;
    progressAreaTime.style.setProperty('--x',x+"px");
    progressAreaTime.style.display = "block";

    let videoDuration = mainVideo.duration;
    let progressTime = Math.floor((x/progressWidthval)*videoDuration);

    let currentMin = Math.floor(progressTime/60);
    let currentSec = Math.floor(progressTime % 60);

    currentSec < 10 ? currentSec ="0"+currentSec : currentSec;
    progressAreaTime.innerHTML =  currentMin +":"+ currentSec;
})

progressArea.addEventListener('mouseleave',(e)=>{

    progressAreaTime.style.display = "none";

})


// Auto play 

auto_play.addEventListener("click", () =>
 {
    auto_play.classList.toggle("active");
    if (auto_play.classList.contains("active")) {
      auto_play.title = "Autoplay is on";
    } else {
      auto_play.title = "Autoplay is off";
    }
  });


  mainVideo.addEventListener("ended", () => {
    if (auto_play.classList.contains("active")) {
      playVideo();
    } else {
      play_pause.innerHTML = "replay";
      play_pause.title = "Replay";
    }
  });


   // Picture in picture


   picture_in_picture.addEventListener("click", () => {
    mainVideo.requestPictureInPicture();
  });

// Full screen function

  fullscreen.addEventListener("click", () => {
    if (!video_player.classList.contains("openFullScreen")) {
      video_player.classList.add("openFullScreen");
      fullscreen.innerHTML = "fullscreen_exit";
      mainVideo.style.height = "720px";
      video_player.requestFullscreen();
      // video_player.webkitRequestFullscreen();
    } else {
      video_player.classList.remove("openFullScreen");
      fullscreen.innerHTML = "fullscreen";
      document.exitFullscreen();
      mainVideo.style.height = "447px";
    }
  });


  settingsBtn.addEventListener("click", () => {
    settings.classList.toggle("active");
    settingsBtn.classList.toggle("active");
    // if (
    //   captionsBtn.classList.contains("active") ||
    //   captions.classList.contains("active")
    // ) {
    //   captions.classList.remove("active");
    //   captionsBtn.classList.remove("active");
    // }
  });



     // Playback Rate

  playback.forEach((event) => {
    event.addEventListener("click", () => {
      removeActiveClasses(playback);
      event.classList.add("active");
      let speed = event.getAttribute("data-speed");
      mainVideo.playbackRate = speed;
    });
  });


const settingDivs = video_palyer.querySelectorAll('#settings > div')
const settingBack = video_player.querySelectorAll('#settings > div .back_arrow');
const quality_ul = video_player.querySelector("#settings > [data-label='quality'] ul");
const qualities = video_player.querySelectorAll("source[size]");

qualities.forEach(event=>{
let quality_html=  `<li data-quality="${event.getAttribute('size')}">${event.getAttribute('size')}p</li>`;
quality_ul.insertAdjacentHTML('afterbegin',quality_html);
})


const vid_q=document.getElementById("all_quality");
// const quality_li = video_player.querySelectorAll(".settings > [data-label='quality'] ul > li");
const quality_li = vid_q.querySelectorAll('li');
  quality_li.forEach((event) => {
    event.addEventListener('click', (e) => {

      let quality = event.getAttribute('data-quality');
      console.log("current quality " + quality);
      let curr_src = mainVideo.src;
      let dot_in = curr_src.lastIndexOf(".");
      let file_name = curr_src.substring(0, dot_in);

      console.log(file_name);
      let f_360 = file_name+"_360.mp4";
      console.log(f_360);
      let video_current_duration = mainVideo.currentTime;
       mainVideo.src = f_360;

       mainVideo.currentTime = video_current_duration;
       playVideo();
      

      // const myArray = curr_src.split(".");
      // console.log(myArray.pop());
      // console.log(myArray);
      // myArray.push("_360.mp4");
      // console.log(myArray);

        // removeActiveClasses(quality_li);
        // event.classList.add('active');
        // qualities.forEach(event => {
          // if (event.getAttribute('size') == quality) {
          //   let video_current_duration = mainVideo.currentTime;
          //   let video_source = event.getAttribute('src');
          //   mainVideo.src = video_source;
          //   mainVideo.currentTime = video_current_duration;
          //   playVideo();
          // }
      // })

    })
  })


settingshome.forEach((event)=>
{
    event.addEventListener('click',(e)=>{
     console.log("got it");
      let setting_label = e.target.getAttribute('data-label');
        removeActiveDiv(settingDivs);

        for(let i=0;i<settingDivs.length;i++)
        {
          if (settingDivs[i].getAttribute('data-label') == setting_label) {
            settingDivs[i].removeAttribute('hidden');
          } else {
            settingDivs[i].setAttribute('hidden', "");
          }
        }
    })
})


settingBack.forEach((event) => {
  event.addEventListener('click', (e) => {
    let setting_label = e.target.getAttribute('data-label');
    console.log("click it");
    for (let i = 0; i < settingDivs.length; i++) {
      if (settingDivs[i].getAttribute('data-label') == setting_label) {
        settingDivs[i].removeAttribute('hidden');
      } else {
        settingDivs[i].setAttribute('hidden', "");
      }
    }
  
   back_set_act =  document.getElementById('set_home'); 
  back_set_act.removeAttribute("hidden");     })
})

  function removeActiveClasses(e) {
    e.forEach((event) => {
      event.classList.remove("active");
    });
  }

  function removeActiveDiv(e) {
    e.forEach((event) => {
      event.setAttribute("hidden","");
    });
  }

  // Store video duration and video path in local storage
 

  // window.addEventListener("unload",()=>{
  //   let duration = localStorage.setItem('duration',""+mainVideo.currentTime+"");
  //   let setSrc = localStorage.setItem('src',""+mainVideo.getAttribute('src')+"");

  // })


  // window.addEventListener('load',()=>{

  //   let getduration = localStorage.getItem('duration');
  //   let getSrc = localStorage.getItem('src');
  //   if(getSrc)
  //   {
  //       mainVideo.src = getSrc;
  //       mainVideo.duration = getduration;

  //   }

  // })
  

  function addComment() {
    var usernameInput = document.getElementById('username-input');
    var commentInput = document.getElementById('comment-input');
    
    var username = usernameInput.value.trim();
    var commentText = commentInput.value.trim();
  
    if (username !== '' && commentText !== '') {
      var commentList = document.getElementById('comments-list');
  
      var li = document.createElement('li');
      li.className = 'comment';
      li.innerHTML = '<strong>' + username + '</strong>: ' + commentText;
  
      commentList.appendChild(li);
      commentInput.value = '';
      add_comment_in_db(commentText);
    } else {
      alert('Please enter your name and a comment.');
    }
  }
  
function add_comment_in_db(commentText){
  const url=$('.comment_form').attr('action');
    $.ajax({
      type: 'POST',
      url:url,
      data:{'comment':commentText,
          'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()
      
         },
         success:function(response){
             if(response.disliked ===true){
               console.log("comment added")
             }
         },
         error:function(response){
             console.log('failed', response)
         }
     }) 

}




jQuery(function($) {
  var show_char = 350;
  var ellipses = "... ";
  var content = $(".tabcontent").text(); //change here ..

  if (content.length > show_char) {
    var a = content.substr(0, show_char);
    var b = content.substr(show_char - content.length);
    var html = a + "<span class='truncated'>" + ellipses + "</span><span class='truncated' style='display:none'>" + b + "</span><a class='read-more' style='font-weight: bold' href='#'>Read more</a>"; //move read more outside
    $(".tabcontent").html("<p>" + html + "</p>");
  }

  $(".read-more").click(function(e) {
    e.preventDefault();
    $(".read-more").text() == "Read more" ? $(".read-more").text("Read less") : $(".read-more").text("Read more") //change here..
    $(".tabcontent .truncated ").toggle();
  });
});
      
var watchtime_res ='';
var prevtime = 0;
$('#main_video').on('timeupdate',function() {
  if(watchtime_res==='stop')
    {
    return }
  // use parseInt to round to whole seconds
  var ct = parseInt(this.currentTime);
  // only eval once per second inc, since timeupdate pops ~4 times per second
  if (this.lastTime!=ct) {
    // if current time is divisible by 10 then an inc of 10s has passed
    if (ct%10===0) {
      console.log(ct,'seconds have passed'); 
      console.log(ct-prevtime);
      if((ct-prevtime) ===10){
        console.log("calling ajax");
        let video_id = get_video_id();
        calculate_watch_time(video_id)

        prevtime =ct;
      }
      else{
        prevtime =ct;
      }
     
         
    }
  }
  this.lastTime=ct;
  
});


function calculate_watch_time(video_id){
    $.ajax({
      type: 'POST',
      url:'/video_duration/' + video_id,
      data:{
          'video_id':video_id,
          'video_duration':mainVideo.duration,
          'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()
      
         },
         success:function(response){
            console.log(response.success)
            if(response.success ==='stop')
              { watchtime_res = 'stop'}
             
         },
         error:function(response){
             console.log('failed', response)
         }
     }) 

}



