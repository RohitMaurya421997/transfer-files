document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
   
    const loginLink = document.getElementById('loginLink'); 
  
    loginLink.addEventListener('click', function(event) {

      loginForm.classList.remove('hidden');
    });
  
   
  });
  

  