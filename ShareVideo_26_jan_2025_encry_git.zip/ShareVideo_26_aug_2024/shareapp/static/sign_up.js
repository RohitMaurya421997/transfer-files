const password = document.querySelector('#newPassword');
const errorList = document.querySelector('.errorList');
var sign_up_head = document.querySelector('.head_h2');

var sign_up_form = document.querySelector('.form');

const rules = [
 { message:'At least 1 lower letter.', regex:/[a-z]+/ },
 { message:"At least 1 capital letter.",  regex:/[A-Z]+/ },
 { message:"At least 4 characters", regex:/.{4,}/ },
 { message:"At least 1 number", regex:/[0-9]+/ },
 { message:"At least 1 special character", regex:/[^A-Za-z0-9]+/ }
];

function passwordValidation (e) {
  const errors = [];
  errorList.innerHTML = '';
  
  for (let condition of rules) {
    if (!condition.regex.test(e.target.value)) {
       errors.push(condition.message)
    }
  }

  if (errors.length !== 0) {
    for (let i = 0; i < errors.length; i++) {
     const errorListItem = document.createElement('li')

     errorList.appendChild(errorListItem)
     errorListItem.innerHTML = errors[i]
    }
    sign_up_head.style.marginTop = "180px"
    sign_up_form.style.height = "900px"
    return {
      valid: false,
      errors
    }
    
  }
  sign_up_head.style.marginTop = "34px"
  sign_up_form.style.height = "630px"
   return {
      valid: true,
      errors
    }
}

password.addEventListener('input', passwordValidation);