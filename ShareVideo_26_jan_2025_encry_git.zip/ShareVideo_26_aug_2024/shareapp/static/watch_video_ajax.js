

function likedvideo(){
    $(".dislike-icon").removeClass("text-blue-700")
         const video_id=$('#like_count').val();
         const url=$('.like-form').attr('action');
         let dislike_count= document.getElementById("real_dislike_count").innerText
          let int_dislike = Number(dislike_count);
         if (int_dislike>0){
            document.getElementById("real_dislike_count").innerText = int_dislike-1;
         }
        
       $.ajax({
           type: 'POST',
           url:url,
           data:{
               'video_id':video_id,
               'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()
           },
           success:function(response){
            console.log(response.liked)
            if(response.liked===true){
                $('.like-icon').addClass('text-blue-700')
              }else{
                $('.like-icon').removeClass('text-blue-700')
              }
            
              document.getElementById("real_like_count").innerText=response.likes_count;
           },
           error:function(response){
            console.log("Failed ", response)
           }
       })
    }


    //dislike ajax call

    function dislike_video(){
        $('.like-icon').removeClass('text-blue-700')
        const video_id=$('#dislike_count').val();
        const url=$('.dislike-form').attr('action');

        let like_count= document.getElementById("real_like_count").innerText
        let int_like = Number(like_count);
       if (int_like>0){
          document.getElementById("real_like_count").innerText = int_like-1;
       }
          $.ajax({
            type: 'POST',
            url:url,
            data:{
                'video_id':video_id,
                'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()
            
               },
               success:function(response){
                   if(response.disliked ===true){
                       $(".dislike-icon").addClass("text-blue-700")
                   }else{
                       $(".dislike-icon").removeClass("text-blue-700")
                   }
               
                   document.getElementById("real_dislike_count").innerText=response.dislike_count;
                   
               },
               error:function(response){
                   console.log('failed', response)
               }
           }) 
   
   }


   //subcriber ajax call
function Subscribed(){
       const channel_id=$('#subscribe_btn').val()
       const url=$('.Subcriber_form').attr('action');
        
       $.ajax({
        type: 'POST',
        url:url,
        data:{
            'channel_id':channel_id,
            'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()
        },
        success:function(response){
            if(response.Subscribed==true){
                $('#subscribe_btn').removeClass("bg-red-700")
                 $('#subscribe_btn').addClass("bg-gray-600")
                 $('#subscribe_btn').text("Subscribed")
                 
             }else{
                $('#subscribe_btn').removeClass("bg-gray-600")
                $('#subscribe_btn').addClass("bg-red-700")
                $('#subscribe_btn').text("Subscribe")

             }
          
             $('#sub_count').text(response.num_subscribers)
       
           console.log(response)
        },
        error:function(response){
           console.log("failed ", response)
        }
    })

 
}


$(document).ready(function(){
        
    var numToShow = 3;
    $("#comments-list li").hide();
    $('.comments-container ul').each(function(){
       var list = $(this).children("li");
       var button = $(this).siblings("#next");
       var less = $(this).siblings('#less');
       var numInList = list.length;
       if (numInList > numToShow) {
          button.show();
          less.hide();
       }
      list.slice(0, numToShow).show();
    });
    
    $('#next').click(function(){
      var list = $(this).siblings("#comments-list").children("li");
      var numInList = list.length;
      console.log(numInList);
      var showing = list.filter(':visible').length;
      list.slice(showing - 1, showing + numToShow).fadeIn();
      var nowShowing = list.filter(':visible').length;
      console.log(nowShowing)
      $(this).next('#less').show();
      if (nowShowing >= numInList) {
       
        $(this).hide();
        $(this).next('#less').show();
      }
    });

    $('#less').click(function () {
      $(this).siblings("#comments-list").children("li").not(':lt(3)').hide();
      $(this).siblings('#next').show();
      $(this).hide();
    });
    
});


