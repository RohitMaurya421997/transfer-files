// Access the thumbnail input element
const thumbnailInput = document.getElementById('thumbnail');
const thumbnailPreview = document.getElementById('thumbnail-preview-image');
const uploded_vide_id = document.getElementById('video_id');
const progressbar = document.getElementById('progress_sec');
const show_progressbar = document.getElementById('real_progress');
const textarea = document.getElementById('mainTextarea');
const inputInsideTextarea = document.getElementById('inputInsideTextarea');
const progress_bar_cancel = document.getElementById('cancel_id');
const inputInsideTextarea_demo = document.getElementById('inputInsideTextarea_demo');
const upload_success = document.getElementById('video_success');
const upload_failed = document.getElementById('video_failed');
const csrf_token = document.getElementsByName('csrfmiddlewaretoken');
const added_tags = document.getElementById('video_tags');
// Listen for changes in the file input
thumbnailInput.addEventListener('change', function(event) {
  const file = event.target.files[0]; // Get the uploaded file

  if (file) {
    const reader = new FileReader(); // Create a FileReader object

    // Set up the FileReader to display the image preview
    reader.onload = function(e) {
      thumbnailPreview.src = e.target.result;
      thumbnailPreview.style.display = 'block';
    };

    // Read the file as a data URL (base64 encoded image)
    reader.readAsDataURL(file);
  } else {
    thumbnailPreview.src = '#';
    thumbnailPreview.style.display = 'none';
  }
});


// Access the video drop area and input element
const videoDropArea = document.getElementById('video-drop-area');
const videoInput = document.getElementById('video');

// Prevent default behavior on dragover and dragenter events
['dragover', 'dragenter'].forEach(eventName => {
  videoDropArea.addEventListener(eventName, function(event) {
    event.preventDefault();
    event.stopPropagation();
  }, false);
});

// Highlight drop area on dragenter
videoDropArea.addEventListener('dragenter', function() {
  videoDropArea.style.border = '2px dashed #007bff';
});

// Restore border on dragleave or drop
['dragleave', 'drop'].forEach(eventName => {
  videoDropArea.addEventListener(eventName, function() {
    videoDropArea.style.border = '2px dashed #ccc';
  }, false);
});

// Handle dropped files
videoDropArea.addEventListener('drop', function(event) {
  event.preventDefault();
  event.stopPropagation();

  const files = event.dataTransfer.files;

  // Check if dropped files are videos
  const videoFiles = Array.from(files).filter(file => file.type.startsWith('video/'));

  // Display information about dropped videos (for demonstration)
 
  handle_uploaded_video(videoFiles);

  // You can perform further operations with the dropped video files here
});

// Click event on the video drop area triggers file input click
videoDropArea.addEventListener('click', function() {
  videoInput.click();
});

// Change event on file input triggers file selection
videoInput.addEventListener('change', function() {
  const files = videoInput.files;

  // Check if selected files are videos
  const videoFiles = Array.from(files).filter(file => file.type.startsWith('video/'));

  // Display information about selected videos (for demonstration)

  handle_uploaded_video(videoFiles);

  // You can perform further operations with the selected video files here
});




function addInputs() {
  
  const text = textarea.value.trim();
  const inputs = text.split(',');
  var len_tg = check_tag_length(inputs[0].toLowerCase());
  if(len_tg>=600){
    textarea.value = ''; 
    return;
  }
  textarea.value = ''; // Clear previous inputs

  inputs.forEach(value => {
    
     if (value){
      
      var all_tags_len = len_tg+value.length;
      
      if(all_tags_len>=600){
          value = value.substring(0,600-len_tg);
      }
    const input = document.createElement('button');
    input.textContent=value.toLowerCase();
    const new_div = document.createElement('div');
    const cross_sign = document.createElement('i');
    input.className = "remove-btn";
    input.style.display= "flex";
    input.style.marginLeft = "4px";
    input.style.marginTop = "4px";
    input.style.padding = "4px 8px"; 
    input.style.cursor = "pointer";
    input.setAttribute('value', value.trim());
    new_div.className = "removeButton";
    new_div.style.marginLeft = "6px";
   new_div.onclick = testFunction;
    cross_sign.className = "fas fa-times cross-icon";
    new_div.appendChild(cross_sign);
    input.appendChild(new_div);
    inputInsideTextarea_demo.appendChild(input);
 
    
    }
  });
}

textarea.addEventListener('keyup', function(event) {
  const key = event.key;

  if (key === ',') {
   
    addInputs();
  }
});

function testFunction(event){
event.target.parentNode.parentNode.remove();
check_tag_length(null);
};


function video_tags_handle(){
  const  all_tags = inputInsideTextarea_demo.getElementsByTagName("button");
  let temp_tags = "not_val";
  if(all_tags.length>0){
    for(let i = 0;i<all_tags.length;i++){
      if (temp_tags==="not_val"){
        temp_tags = all_tags[i].innerText;
        continue
      }
       
      temp_tags = temp_tags+"~"+all_tags[i].innerText;     
  
    }
    added_tags.value = temp_tags;
    
  }


}

function check_tag_length(alrdy_ext_tag){
var tags_ch_len = [];
const  all_tags = inputInsideTextarea_demo.getElementsByTagName("button");
if(all_tags.length>0){
  for(let i = 0;i<all_tags.length;i++){
    if(alrdy_ext_tag===all_tags[i].innerText){
        return 700;
    }
   tags_ch_len.push(all_tags[i].innerText);
   

  }
}
var sum = 0
tags_ch_len.forEach(val => {
  sum = sum +val.length;
  
});

return sum;
}




function add_tags() {
  const text = textarea.value.trim();
  const inputs = text;
  var len_tg = check_tag_length(text.toLowerCase());
  if(len_tg>=600){
    textarea.value = ''; 
    return;
  }
 
  
  textarea.value = ''; // Clear previous inputs

   var value = text;
      if (value){
        
        var all_tags_len = len_tg+value.length;
       
        if(all_tags_len>=600){
            value = value.substring(0,600-len_tg);
        }
        
      const input = document.createElement('button');
      input.textContent=value.toLowerCase();
      const new_div = document.createElement('div');
      const cross_sign = document.createElement('i');
      input.className = "remove-btn";
      input.style.display= "flex";
      input.style.marginLeft = "4px";
      input.style.marginTop = "4px";
      input.style.padding = "4px 8px"; 
      input.style.cursor = "pointer";
      input.setAttribute('value', value.trim());
      new_div.className = "removeButton";
      new_div.style.marginLeft = "6px";
      new_div.onclick = testFunction;
      cross_sign.className = "fas fa-times cross-icon";
      new_div.appendChild(cross_sign);
      input.appendChild(new_div);
      inputInsideTextarea_demo.appendChild(input);
      
    }

      

}


function handle_uploaded_video(videofile){


    const fd = new FormData();
    fd.append('csrfmiddlewaretoken',csrf_token[0].value)
    fd.append('video',videofile[0])

    $.ajax({

      type:'POST',
      url:'/vidup/',
      enctype:'multipart/form-data',
      data:fd,
      beforeSend:function(){
        progressbar.style.display = 'block';
        progress_bar_cancel.style.display='block';

      },

      xhr:function(){
        const xhr = new window.XMLHttpRequest();
        xhr.upload.addEventListener('progress',e=>{
          if(e.lengthComputable){
            const percent = e.loaded/e.total *100
            show_progressbar.style.width = ""+percent+"%";
          }
        })

        progress_bar_cancel.addEventListener('click',()=>{
          xhr.abort();
          progressbar.style.display = 'none';
          progress_bar_cancel.style.display='none';
        })
          return xhr
      },
      success: function(response){
          
        upload_success.style.display = 'block';
        progressbar.style.display = 'none';
        progress_bar_cancel.style.display='none';
        uploded_vide_id.value = response.video_id;
      },
      error:function(error){
        upload_failed.style.display = 'block';
        progressbar.style.display = 'none';
        progress_bar_cancel.style.display='none';
      },
      cache:false,
      contentType:false,
      processData:false
    })

}